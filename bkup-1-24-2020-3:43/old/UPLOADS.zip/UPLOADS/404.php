<?php
  define("_VALID_PHP", true);
  require_once("init.php");
?>
<?php require_once (THEMEDIR . "/404.tpl.php");?>