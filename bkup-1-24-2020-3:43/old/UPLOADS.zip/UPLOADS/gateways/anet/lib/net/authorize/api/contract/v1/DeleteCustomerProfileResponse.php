<?php

namespace net\authorize\api\contract\v1;

/**
 * Class representing DeleteCustomerProfileResponse
 */
class DeleteCustomerProfileResponse extends ANetApiResponseType
{


}

