<?php

namespace net\authorize\api\contract\v1;

/**
 * Class representing UpdateSplitTenderGroupResponse
 */
class UpdateSplitTenderGroupResponse extends ANetApiResponseType
{


}

